(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/hCaptcha.jsx-4eb6e4ad.js")
    );
  })().catch(console.error);

})();

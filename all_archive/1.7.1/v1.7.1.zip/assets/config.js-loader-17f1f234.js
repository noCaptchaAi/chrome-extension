(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/config.js-42b7d950.js")
    );
  })().catch(console.error);

})();

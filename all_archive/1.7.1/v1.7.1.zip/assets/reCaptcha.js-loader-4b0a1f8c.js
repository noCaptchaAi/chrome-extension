(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/reCaptcha.js-5dbfd97c.js")
    );
  })().catch(console.error);

})();

(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/recap_speech_ai.js-6759ed01.js")
    );
  })().catch(console.error);

})();

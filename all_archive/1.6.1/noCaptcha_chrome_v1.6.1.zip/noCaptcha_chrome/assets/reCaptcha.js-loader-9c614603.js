(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/reCaptcha.js-3f9697dc.js")
    );
  })().catch(console.error);

})();
